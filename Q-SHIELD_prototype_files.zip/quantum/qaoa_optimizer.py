"""
Q-SHIELD: QAOA optimizer demo
Uses only synthetic, area-level data. It does not identify people or substances.
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import QAOAAnsatz
from qiskit.quantum_info import Operator, SparsePauliOp, Statevector

AREAS = ["Area A", "Area B", "Area C", "Area D"]
RISKS = np.array([0.82, 0.35, 0.91, 0.67])
BUDGET = 2
PENALTY = 2.0

def qubo_cost(bits):
    """Cost to minimize: negative risk benefit + penalty for wrong number selected."""
    selected = np.array(bits, dtype=int)
    return -float(np.dot(RISKS, selected)) + PENALTY * (selected.sum() - BUDGET) ** 2

def cost_operator():
    n = len(AREAS)
    diagonal = []
    for integer in range(2**n):
        bits = [(integer >> i) & 1 for i in range(n)]
        diagonal.append(qubo_cost(bits))
    return SparsePauliOp.from_operator(Operator(np.diag(diagonal)))

def expected_cost(state, diagonal):
    probs = np.abs(state.data) ** 2
    return float(np.real(np.dot(probs, diagonal)))

def run_qaoa_grid():
    n = len(AREAS)
    op = cost_operator()
    ansatz = QAOAAnsatz(cost_operator=op, reps=1, flatten=True)

    # QAOAAnsatz contains two parameters for reps=1.
    params = list(ansatz.parameters)
    if len(params) != 2:
        raise RuntimeError(f"Unexpected QAOA parameters: {params}")

    diagonal = np.array([qubo_cost([(i >> j) & 1 for j in range(n)])
                         for i in range(2**n)])

    best = None
    # Small grid keeps the prototype fast and easy to reproduce.
    for gamma in np.linspace(0.0, np.pi, 13):
        for beta in np.linspace(0.0, np.pi/2, 13):
            bound = ansatz.assign_parameters([gamma, beta])
            state = Statevector.from_instruction(bound)
            energy = expected_cost(state, diagonal)
            if best is None or energy < best["energy"]:
                best = {"energy": energy, "gamma": gamma, "beta": beta, "state": state}

    probs = np.abs(best["state"].data) ** 2
    ranked = sorted(range(2**n), key=lambda i: probs[i], reverse=True)

    # Prefer valid bitstrings satisfying the intervention budget.
    valid = [i for i in ranked if sum((i >> j) & 1 for j in range(n)) == BUDGET]
    winner = valid[0]
    selected = [AREAS[j] for j in range(n) if (winner >> j) & 1]

    return {
        "selected_areas": selected,
        "bitstring": format(winner, f"0{n}b"),
        "energy": best["energy"],
        "gamma": best["gamma"],
        "beta": best["beta"],
        "circuit": ansatz,
    }

if __name__ == "__main__":
    result = run_qaoa_grid()
    print("Q-SHIELD QAOA RESULT")
    print("Selected areas:", result["selected_areas"])
    print("Bitstring:", result["bitstring"])
    print("Best energy:", round(result["energy"], 4))
    print("\nCircuit:")
    print(result["circuit"].draw())
