# Q-SHIELD prototype files

Upload these folders/files into the Q-SHIELD GitHub repository.

## Run locally

1. Install Python.
2. Run `pip install -r requirements.txt`.
3. Run `streamlit run app/app.py`.

The prototype uses synthetic area-level data and QAOA. It is for prevention-resource planning, not individual tracking.
