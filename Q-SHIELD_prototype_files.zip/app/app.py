import streamlit as st
import pandas as pd
from quantum.qaoa_optimizer import run_qaoa_grid

st.set_page_config(page_title="Q-SHIELD", page_icon="⚛️", layout="wide")

st.title("⚛️ Q-SHIELD")
st.subheader("Quantum AI-Based Drug-Abuse Risk Mapping & Prevention")

st.info(
    "Prototype using synthetic, area-level data. "
    "It is designed for prevention planning and does not identify individuals "
    "or locate illegal substances."
)

data = pd.DataFrame({
    "Area": ["Area A", "Area B", "Area C", "Area D"],
    "Risk Score": [0.82, 0.35, 0.91, 0.67],
})
data["Risk Level"] = pd.cut(
    data["Risk Score"], bins=[0, 0.4, 0.7, 1.0],
    labels=["Low", "Medium", "High"], include_lowest=True
)

st.write("### Area-level risk assessment")
st.dataframe(data, use_container_width=True)

if st.button("⚛️ Run QAOA Optimization", type="primary"):
    with st.spinner("Running QAOA prototype..."):
        result = run_qaoa_grid()

    st.success("Quantum optimization completed.")
    st.write("### Priority intervention areas")
    st.write(", ".join(result["selected_areas"]))

    c1, c2, c3 = st.columns(3)
    c1.metric("Selected areas", len(result["selected_areas"]))
    c2.metric("QAOA energy", f'{result["energy"]:.3f}')
    c3.metric("Bitstring", result["bitstring"])

    st.write("### Recommended prevention actions")
    st.write(
        "Prioritize awareness programs, counselling access, "
        "healthcare outreach and rehabilitation-resource planning."
    )

    st.write("### QAOA circuit")
    st.code(str(result["circuit"].draw()), language="text")

st.caption(
    "Responsible AI note: use aggregated/anonymized data only. "
    "This is a decision-support prototype, not a law-enforcement or diagnostic system."
)
